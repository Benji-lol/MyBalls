package at.fhb.iti.algodat.balls;

import at.fhb.iti.algodat.balls.balls.BasicBallRectangle;

public class BallRectangle extends BasicBallRectangle {

	private int ballsInRectangle;

	public BallRectangle(int d, int e, int f, int g) {
		super(d,e,f,g);
		this.ballsInRectangle = 0;
	}

	public synchronized void occupy() {
		while(ballsInRectangle>=3){
			try {
				wait();
			} catch (InterruptedException e) {

			}
		}
		ballsInRectangle++;
	}

	public synchronized void free() {
		ballsInRectangle--;
		notifyAll();
	}
}
