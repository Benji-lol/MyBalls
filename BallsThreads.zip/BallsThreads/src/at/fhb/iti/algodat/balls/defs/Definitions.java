package at.fhb.iti.algodat.balls.defs;

public class Definitions {

	public static final int OFFSET = 4;
	public static final int SIZEX = 1200;
	public static final int SIZEY = 800;

	public static final int DELAY = 25;
}
