package at.fhb.iti.algodat.balls;

import at.fhb.iti.algodat.balls.balls.BasicBall;
import at.fhb.iti.algodat.balls.defs.Definitions;
import at.fhb.iti.algodat.balls.grafics.BallsPanel;

public class Ball extends BasicBall implements Runnable {

	private BallRectangle theRectangle;
	private Thread theThread;

	private boolean running = true;
	public Ball(BallsPanel ballsPanel, BallRectangle br) {
		super(ballsPanel);
		theRectangle = br;

		theThread = new Thread(this);
		theThread.start();

	}

	public void run() {
		while (running) {
			while(!isTouching(theRectangle) && running) {
				move();
				delay();
			}
			theRectangle.occupy();
			while(isTouching(theRectangle) && running){
				move();
				delay();
			}
			theRectangle.free();
		}
	}

	public void stop() {
		running = false;
	}

	private void delay() {
		try { Thread.sleep(Definitions.DELAY ); } catch (InterruptedException e) {}
	}

}
